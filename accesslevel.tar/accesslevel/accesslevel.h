#include "accesslevel.c"

#ifndef ACCESSLEVEL_H
#define ACCESSLEVEL_H

//prototypes for get and set functions that invoke syscall
int set_access_level(int pid, int new_level);
int get_access_level(int pid);

//prototypes for harness functions
int* retrieve_set_access_params(int pid, int new_level);
int* retrieve_get_access_params(int pid);
int interpret_set_access_result(int ret_value);
int interpret_get_access_result(int ret_value);

#endif
