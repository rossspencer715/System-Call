//#include "../../../usr/rep/src/reptilian-kernel/sys/syscall.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

int set_access_level(int pid, int new_level){
	return syscall(335, pid, new_level);
}

int get_access_level(int pid){
	return syscall(336, pid);
}

int* retrieve_set_access_params(int pid, int new_level){
	//size 2-4
	int* params = (int*) malloc(4*sizeof(int));
	params[0] = 335;
	params[1] = 2;
	params[2] = pid;
	params[3] = new_level;
	return params;
}

int* retrieve_get_access_params(int pid){
	//size 2-4
	int* params = (int*) malloc(4*sizeof(int));
	params[0] = 336;
	params[1] = 1;
	params[2] = pid;
	return params;
}

int interpret_set_access_result(int ret_value){
	return ret_value;
}

int interpret_get_access_result(int ret_value){
	return ret_value;
}
